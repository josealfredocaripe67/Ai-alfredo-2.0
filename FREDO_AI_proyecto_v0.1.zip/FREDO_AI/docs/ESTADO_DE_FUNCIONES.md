# Estado de las funciones (v0.1.0)

Leyenda: **Escrito** = existe en el código. **Compilado** = compiló sin errores. **Probado** = ejecutado en un dispositivo y verificado.
A la fecha de este documento, **ninguna función está compilada ni probada** (no había Android SDK, Gradle ni red en el entorno de desarrollo).

| Función | Escrito | Compilado | Probado | Notas |
|---|---|---|---|---|
| Chat de texto con historial persistente (Room) | Sí | No | No | Sesiones por perfil; «Nueva» y «Borrar historial» |
| Proveedor OpenAI / compatible | Sí | No | No | `/chat/completions`, sin streaming |
| Proveedor Anthropic (Claude) | Sí | No | No | `/v1/messages`; modelo por defecto editable, verificar nombre |
| Proveedor Google Gemini | Sí | No | No | `generateContent`, clave en cabecera |
| Cambio de proveedor sin tocar el resto | Sí | No | No | Interfaz `AiProvider` |
| Clave API cifrada (Keystore AES-GCM) | Sí | No | No | Nunca en código/APK/logs |
| Solo conexiones https | Sí | No | No | Las `http://` se rechazan (servidores locales sin cifrar no funcionarán) |
| Errores comprensibles (red, clave, cuota, modelo) | Sí | No | No | Mapeo por código HTTP |
| Memoria con esquema de la guía (tipo, confianza, sensibilidad, estado, fecha de revisión*) | Sí | No | No | *`reviewDate` existe en la base de datos, aún sin interfaz |
| Revisar / confirmar / editar / retirar / eliminar recuerdos | Sí | No | No | |
| Recuperación de solo lo pertinente | Sí | No | Parcial | Hay 3 pruebas unitarias escritas (`MemoryRetrieverTest`), **no ejecutadas** |
| Importar `perfil_inicial.json` como pendiente | Sí | No | No | Parser propio con `org.json` |
| Exportar memoria a JSON | Sí | No | No | |
| Perfiles múltiples + PIN opcional | Sí | No | No | PIN con PBKDF2; no cifra datos; no se vuelve a pedir al volver de segundo plano |
| Recuerdos compartibles con familia (sensibilidad ≠ alta) | Sí | No | No | |
| Tema oscuro / claro / sistema, esfera luminosa animada | Sí | No | No | Negro, blanco, azul, plata |
| Diagnóstico (proveedor, modelo, clave sí/no, prueba de conexión) | Sí | No | No | Cuotas restantes no disponibles |
| Reglas de seguridad emocional en el prompt | Sí | No | No | Solo instrucciones al modelo; **no** hay detección propia de crisis |
| **Búsqueda web con fuentes** | **No** | — | — | Pendiente. El prompt indica al modelo que NO afirme haber navegado |
| **Voz (entrada/salida)** | **No** | — | — | Pendiente |
| **Importar documentos y chats** | **No** | — | — | Pendiente (solo se importa el perfil JSON) |
| **Streaming de respuestas** | **No** | — | — | Pendiente |
| **Render de Markdown en respuestas** | **No** | — | — | Se muestra texto plano |
| **Modo educativo dedicado** | **No** | — | — | Solo instrucciones generales en el prompt |
| **Presupuesto/cuotas, WorkManager** | **No** | — | — | No hacen falta aún |
| **Análisis de los chats de WhatsApp** | **No** | — | — | No realizado; no hay recuerdos derivados de los chats |

## Límites conocidos
- El APK de GitHub Actions es **debug** (firmado con clave de depuración). Para distribuirlo en serio hay que crear una firma propia.
- Los modelos por defecto son editables y pueden estar desactualizados.
- El historial y la memoria están en la base de datos local sin cifrar (protegida por el sandbox de Android).
