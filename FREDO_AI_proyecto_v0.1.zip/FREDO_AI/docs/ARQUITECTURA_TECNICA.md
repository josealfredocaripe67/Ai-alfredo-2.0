# Arquitectura técnica

MVVM sencillo, inyección manual (`AppContainer`), Kotlin Coroutines/Flow, sin librerías de red ni de serialización externas.

```
com.fredo.ai
├─ FredoApp / MainActivity / di.AppContainer     Arranque y dependencias
├─ data
│  ├─ db            Room: ProfileEntity, MessageEntity, MemoryEntity + DAOs
│  ├─ settings      DataStore (ajustes) + SecureKeyStore (claves cifradas, Keystore)
│  ├─ ai            AiProvider (interfaz) + OpenAI/Anthropic/Gemini + HttpJson (HttpURLConnection)
│  ├─ memory        MemoryRetriever (selección pertinente) + ProfileImporter (perfil_inicial.json)
│  └─ *Repository   Chat, Memory, Profile
├─ domain           PromptBuilder (reglas de la guía) + PinHasher (PBKDF2)
└─ ui               Tema, esfera (Orb), pantallas Compose y ViewModels (Chat, Memoria, Perfiles, Ajustes)
```

Flujo de un mensaje: `ChatViewModel.send` → guarda mensaje → `ChatRepository.reply` (lee ajustes y clave, últimos 20 mensajes,
selecciona recuerdos pertinentes, arma el prompt) → `AiProvider.complete` → guarda respuesta o mensaje de error comprensible.

Separación de datos: cada recuerdo y mensaje pertenece a un `profileId`. Un perfil familiar solo ve los suyos y los del
propietario marcados «compartibles» con sensibilidad baja/media.
