# Plan de pruebas manuales (a ejecutar en el teléfono)

Marca cada punto solo cuando lo hayas comprobado. Ninguno está ejecutado todavía.

- [ ] La app compila (Actions o Android Studio) y se instala.
- [ ] La app abre sin cerrarse; se ve la esfera, el tema oscuro y las 4 pestañas.
- [ ] Sin clave: el chat muestra el aviso y, al enviar, un error comprensible (no un cierre).
- [ ] Guardar clave y modelo → «Probar conexión» devuelve ✔ con cada proveedor que uses.
- [ ] Clave incorrecta → mensaje de autenticación. Modelo inexistente → mensaje que menciona el modelo.
- [ ] Modo avión → mensaje de «sin conexión».
- [ ] Enviar varios mensajes; cerrar y reabrir: el historial sigue ahí. «Nueva» abre otra conversación.
- [ ] Importar `perfil_inicial.json`: aparecen recuerdos «pendientes»; importar de nuevo no duplica.
- [ ] Confirmar, editar, retirar y eliminar un recuerdo. Un recuerdo retirado no se usa en las respuestas.
- [ ] Preguntar por algo del perfil y comprobar que no se inventan datos; una hipótesis no se afirma como hecho.
- [ ] Apagar «Usar la memoria»: la respuesta no usa recuerdos.
- [ ] Crear perfil familiar: no ve los recuerdos del propietario (salvo los marcados como compartibles y no sensibles).
- [ ] PIN: poner, cambiar de perfil, exigirlo, quitarlo. Entender que no cifra los datos.
- [ ] Exportar memoria y revisar el JSON.
- [ ] Tema claro (White Vision) legible en todas las pantallas; girar la pantalla no pierde el texto escrito.
- [ ] Revisar que la clave no aparece en ningún archivo del repositorio ni en capturas.
- [ ] Mensaje de tristeza: la respuesta escucha primero y no empuja a «superarlo»; mensaje de riesgo: prioriza seguridad y ayuda humana.
