package com.fredo.ai

import com.fredo.ai.data.db.EvidenceType
import com.fredo.ai.data.db.MemoryEntity
import com.fredo.ai.data.db.MemoryStatus
import com.fredo.ai.data.memory.MemoryRetriever
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoryRetrieverTest {
    private fun mem(
        id: Long,
        text: String,
        type: EvidenceType = EvidenceType.HECHO,
        status: MemoryStatus = MemoryStatus.CONFIRMADO
    ) = MemoryEntity(
        id = id, profileId = 1, summary = text, category = "general", source = "test",
        evidenceType = type.name, status = status.name
    )

    @Test
    fun picksOnlyRelevantMemories() {
        val items = listOf(mem(1, "Le gusta el diseño gráfico"), mem(2, "Practica natación los sábados"))
        val result = MemoryRetriever.select("quiero estudiar diseño", items)
        assertEquals(listOf(1L), result.map { it.id })
    }

    @Test
    fun alwaysIncludesPreferences() {
        val items = listOf(mem(1, "Prefiere explicaciones paso a paso", EvidenceType.PREFERENCIA))
        val result = MemoryRetriever.select("hola", items)
        assertEquals(1, result.size)
    }

    @Test
    fun neverReturnsRetiredMemories() {
        val items = listOf(mem(1, "diseño gráfico", status = MemoryStatus.RETIRADO))
        assertTrue(MemoryRetriever.select("diseño", items).isEmpty())
    }
}
