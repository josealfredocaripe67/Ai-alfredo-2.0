package com.fredo.ai.data.memory

import com.fredo.ai.data.db.EvidenceType
import com.fredo.ai.data.db.Level
import com.fredo.ai.data.db.MemoryEntity
import com.fredo.ai.data.db.MemoryStatus
import org.json.JSONArray
import org.json.JSONObject

data class ImportedProfile(
    val memories: List<MemoryEntity>,
    val customInstructions: String
)

/**
 * Convierte `perfil_inicial.json` (formato de la guía maestra) en recuerdos revisables.
 * Nada se marca como confirmado: todo entra como "pendiente de validar" para que Alfredo lo revise.
 * El archivo NO viaja dentro del APK; se importa desde el almacenamiento del teléfono.
 */
object ProfileImporter {

    fun parse(jsonText: String, profileId: Long): ImportedProfile {
        val root = JSONObject(jsonText)
        val source = "perfil_inicial.json v" + root.optString("profile_version", "?") +
            " (" + root.optString("last_updated", "s/f") + ")"
        val out = ArrayList<MemoryEntity>()

        fun add(
            summary: String,
            category: String,
            type: EvidenceType,
            sensitivity: Level,
            confidence: Level = Level.MEDIA
        ) {
            val s = summary.trim()
            if (s.isEmpty()) return
            out.add(
                MemoryEntity(
                    profileId = profileId,
                    summary = s,
                    category = category,
                    source = source,
                    evidenceType = type.name,
                    confidence = confidence.name,
                    sensitivity = sensitivity.name,
                    status = MemoryStatus.PENDIENTE.name
                )
            )
        }

        val person = root.optJSONObject("person")
        val instructions = ArrayList<String>()
        if (person != null) {
            val name = person.optString("name_for_project")
            if (name.isNotBlank()) add("Nombre que usa para el proyecto: $name.", "identidad", EvidenceType.HECHO, Level.BAJA, Level.ALTA)
            val birth = person.optString("birth_date_shared")
            if (birth.isNotBlank()) add("Fecha de nacimiento compartida: $birth.", "identidad", EvidenceType.HECHO, Level.MEDIA, Level.ALTA)
            val edu = person.optString("education_context")
            if (edu.isNotBlank()) add(edu, "estudios", EvidenceType.HECHO, Level.BAJA)

            person.optJSONObject("family_context")?.let { fam ->
                val mother = fam.optString("mother")
                if (mother.isNotBlank()) add("Su mamá se llama $mother.", "familia", EvidenceType.HECHO, Level.ALTA, Level.ALTA)
                val step = fam.optString("stepfather_or_father_figure")
                if (step.isNotBlank()) add("Figura paterna / padrastro: $step.", "familia", EvidenceType.HECHO, Level.ALTA)
                val bio = fam.optString("biological_father")
                if (bio.isNotBlank()) add("Padre biológico: $bio.", "familia", EvidenceType.HECHO, Level.ALTA)
                val sibs = strings(fam.optJSONArray("siblings_mentioned"))
                if (sibs.isNotEmpty()) {
                    add(
                        "Hermanos mencionados: ${sibs.joinToString(", ")}. El vínculo exacto debe validarse antes de usarlo.",
                        "familia", EvidenceType.HECHO, Level.ALTA, Level.BAJA
                    )
                }
            }

            person.optJSONObject("self_description_and_preferences")?.let { sd ->
                val identity = sd.optString("identity_shared")
                if (identity.isNotBlank()) add("Identidad compartida por él: $identity", "identidad", EvidenceType.HECHO, Level.ALTA, Level.ALTA)
                val keys = listOf("support_style", "humor", "teaching", "correction", "communication")
                val labels = mapOf(
                    "support_style" to "Apoyo emocional",
                    "humor" to "Humor",
                    "teaching" to "Enseñanza",
                    "correction" to "Corrección",
                    "communication" to "Comunicación"
                )
                for (k in keys) {
                    val v = sd.optString(k)
                    if (v.isNotBlank()) {
                        add("${labels[k]}: $v", "comunicación", EvidenceType.PREFERENCIA, Level.BAJA, Level.ALTA)
                        instructions.add("${labels[k]}: $v")
                    }
                }
            }

            val interests = strings(person.optJSONArray("interests"))
            for (i in interests) add("Interés: $i", "intereses", EvidenceType.HECHO, Level.BAJA)

            for (p in strings(person.optJSONArray("initial_patterns_to_validate"))) {
                add("Patrón inicial por validar: $p", "personalidad", EvidenceType.HIPOTESIS, Level.MEDIA, Level.BAJA)
            }

            val values = strings(person.optJSONArray("core_values_self_reported"))
            if (values.isNotEmpty()) {
                add("Valores que quiere conservar (dichos por él): ${values.joinToString(", ")}.", "valores", EvidenceType.HECHO, Level.BAJA, Level.ALTA)
            }

            person.optJSONObject("relational_self_description")?.let { rel ->
                val map = listOf(
                    "when_hurt" to "Cuando se siente herido",
                    "respect_trigger" to "Qué afecta su admiración o respeto",
                    "misunderstood_trait" to "Lo que siente que malinterpretan",
                    "message_to_family" to "Mensaje para su familia"
                )
                for ((k, label) in map) {
                    val v = rel.optString(k)
                    if (v.isNotBlank()) {
                        add("$label (autodescripción del 2026-10-23): $v", "relaciones", EvidenceType.HECHO, Level.ALTA, Level.ALTA)
                    }
                }
            }
        }

        root.optJSONObject("first_interview")?.let { fi ->
            for (c in strings(fi.optJSONArray("careful_interpretations_to_validate"))) {
                add("Interpretación provisional (no confirmada): $c", "relaciones", EvidenceType.HIPOTESIS, Level.ALTA, Level.BAJA)
            }
        }

        return ImportedProfile(out, instructions.joinToString("\n"))
    }

    private fun strings(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        val list = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val s = arr.optString(i)
            if (s.isNotBlank()) list.add(s)
        }
        return list
    }
}
