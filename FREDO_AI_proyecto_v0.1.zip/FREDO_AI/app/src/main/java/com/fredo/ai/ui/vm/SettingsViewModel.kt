package com.fredo.ai.ui.vm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fredo.ai.FredoApp
import com.fredo.ai.data.ConnectionTest
import com.fredo.ai.data.settings.AppSettings
import com.fredo.ai.data.settings.ProviderType
import com.fredo.ai.data.settings.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface TestState {
    data object Idle : TestState
    data object Running : TestState
    data class Done(val result: ConnectionTest) : TestState
}

data class Counts(val messages: Int = 0, val memories: Int = 0)

class SettingsViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as FredoApp).container

    val settings: StateFlow<AppSettings> =
        c.settings.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private val _hasKey = MutableStateFlow(false)
    val hasKey: StateFlow<Boolean> = _hasKey

    private val _test = MutableStateFlow<TestState>(TestState.Idle)
    val test: StateFlow<TestState> = _test

    private val _counts = MutableStateFlow(Counts())
    val counts: StateFlow<Counts> = _counts

    private val _saved = MutableStateFlow(false)
    val saved: StateFlow<Boolean> = _saved
    fun clearSaved() { _saved.value = false }

    fun refresh() {
        viewModelScope.launch {
            val type = c.settings.settings.first().provider
            _hasKey.value = withContext(Dispatchers.IO) { c.keys.has(type) }
            _counts.value = Counts(c.chat.messageCount(), c.chat.memoryCount())
        }
    }

    fun selectProvider(type: ProviderType) {
        viewModelScope.launch {
            c.settings.setProvider(type)
            _test.value = TestState.Idle
            _hasKey.value = withContext(Dispatchers.IO) { c.keys.has(type) }
        }
    }

    /** Guarda dirección y modelo; la clave solo se reemplaza si se escribió una nueva. */
    fun saveConnection(type: ProviderType, baseUrl: String, model: String, newKey: String) {
        viewModelScope.launch {
            c.settings.setConnection(type, baseUrl.trim(), model.trim())
            if (newKey.isNotBlank()) withContext(Dispatchers.IO) { c.keys.save(type, newKey) }
            _hasKey.value = withContext(Dispatchers.IO) { c.keys.has(type) }
            _test.value = TestState.Idle
            _saved.value = true
        }
    }

    fun deleteKey(type: ProviderType) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { c.keys.clear(type) }
            _hasKey.value = false
        }
    }

    fun setTheme(mode: ThemeMode) { viewModelScope.launch { c.settings.setTheme(mode) } }
    fun setMemoryEnabled(enabled: Boolean) { viewModelScope.launch { c.settings.setMemoryEnabled(enabled) } }

    fun runTest() {
        if (_test.value == TestState.Running) return
        viewModelScope.launch {
            _test.value = TestState.Running
            _test.value = TestState.Done(c.chat.testConnection())
        }
    }
}
