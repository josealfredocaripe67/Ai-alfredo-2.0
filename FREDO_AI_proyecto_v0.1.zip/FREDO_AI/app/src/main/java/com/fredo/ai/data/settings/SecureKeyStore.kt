package com.fredo.ai.data.settings

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Guarda las claves API cifradas con AES-GCM. La clave de cifrado vive en Android Keystore
 * y no sale del dispositivo. Las claves API nunca se escriben en logs ni en el código.
 */
class SecureKeyStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("fredo_secure_keys", Context.MODE_PRIVATE)

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    private fun prefKey(type: ProviderType) = "api_key_" + type.name

    fun save(type: ProviderType, apiKey: String) {
        val clean = apiKey.trim()
        if (clean.isEmpty()) {
            clear(type)
            return
        }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val encrypted = cipher.doFinal(clean.toByteArray(Charsets.UTF_8))
        val blob = cipher.iv + encrypted
        prefs.edit().putString(prefKey(type), Base64.encodeToString(blob, Base64.NO_WRAP)).apply()
    }

    fun load(type: ProviderType): String? {
        val stored = prefs.getString(prefKey(type), null) ?: return null
        return try {
            val raw = Base64.decode(stored, Base64.NO_WRAP)
            val iv = raw.copyOfRange(0, IV_SIZE)
            val data = raw.copyOfRange(IV_SIZE, raw.size)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(data), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }

    fun has(type: ProviderType): Boolean = !load(type).isNullOrBlank()

    fun clear(type: ProviderType) {
        prefs.edit().remove(prefKey(type)).apply()
    }

    private companion object {
        const val KEY_ALIAS = "fredo_api_key_wrapper_v1"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val IV_SIZE = 12
    }
}
