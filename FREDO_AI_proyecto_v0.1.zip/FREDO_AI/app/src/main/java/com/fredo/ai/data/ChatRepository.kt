package com.fredo.ai.data

import com.fredo.ai.data.ai.AiException
import com.fredo.ai.data.ai.AiProviderFactory
import com.fredo.ai.data.ai.ChatTurn
import com.fredo.ai.data.db.FredoDatabase
import com.fredo.ai.data.db.MessageEntity
import com.fredo.ai.data.db.ProfileEntity
import com.fredo.ai.data.memory.MemoryRetriever
import com.fredo.ai.data.settings.SecureKeyStore
import com.fredo.ai.data.settings.SettingsStore
import com.fredo.ai.domain.PromptBuilder
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ConnectionTest(val ok: Boolean, val millis: Long, val message: String)

class ChatRepository(
    private val db: FredoDatabase,
    private val settings: SettingsStore,
    private val keys: SecureKeyStore
) {
    private val messages = db.messageDao()
    private val memories = db.memoryDao()
    private val profiles = db.profileDao()

    fun observe(profileId: Long, sessionId: Long): Flow<List<MessageEntity>> =
        if (profileId <= 0L) emptyFlow() else messages.observe(profileId, sessionId)

    suspend fun latestSession(profileId: Long): Long = messages.latestSession(profileId) ?: 0L

    suspend fun addUser(profileId: Long, sessionId: Long, text: String) {
        messages.insert(MessageEntity(profileId = profileId, sessionId = sessionId, role = ChatTurn.USER, content = text))
    }

    suspend fun addAssistant(profileId: Long, sessionId: Long, text: String) {
        messages.insert(MessageEntity(profileId = profileId, sessionId = sessionId, role = ChatTurn.ASSISTANT, content = text))
    }

    suspend fun addError(profileId: Long, sessionId: Long, text: String) {
        messages.insert(
            MessageEntity(profileId = profileId, sessionId = sessionId, role = ChatTurn.ASSISTANT, content = text, isError = true)
        )
    }

    suspend fun clearHistory(profileId: Long) = messages.clearProfile(profileId)

    /** Genera la respuesta usando el proveedor configurado, la memoria pertinente y el historial reciente. */
    suspend fun reply(profile: ProfileEntity, sessionId: Long, userText: String): String {
        val s = settings.settings.first()
        val provider = AiProviderFactory.create(s.provider, s.baseUrl, s.model, keys.load(s.provider))
        val history = messages.lastForContext(profile.id, sessionId, CONTEXT_MESSAGES).reversed()
        val turns = history.map { ChatTurn(it.role, it.content) }
        val selected = if (s.memoryEnabled) {
            val ownerId = profiles.firstOwnerId() ?: -1L
            MemoryRetriever.select(userText, memories.candidates(profile.id, ownerId))
        } else {
            emptyList()
        }
        val today = SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy", Locale("es")).format(Date())
        return provider.complete(PromptBuilder.build(profile, selected, today), turns)
    }

    /** Prueba mínima de conexión: no envía memoria ni historial. */
    suspend fun testConnection(): ConnectionTest {
        val start = System.currentTimeMillis()
        return try {
            val s = settings.settings.first()
            val provider = AiProviderFactory.create(s.provider, s.baseUrl, s.model, keys.load(s.provider))
            provider.complete(
                "Responde únicamente con la palabra OK.",
                listOf(ChatTurn(ChatTurn.USER, "Prueba de conexión."))
            )
            ConnectionTest(true, System.currentTimeMillis() - start, "Conexión correcta con ${s.provider.label} (modelo ${s.model}).")
        } catch (e: AiException) {
            ConnectionTest(false, System.currentTimeMillis() - start, e.userMessage())
        } catch (e: Exception) {
            ConnectionTest(false, System.currentTimeMillis() - start, "Error inesperado: ${e.javaClass.simpleName}")
        }
    }

    suspend fun messageCount(): Int = messages.count()
    suspend fun memoryCount(): Int = memories.count()

    private companion object {
        const val CONTEXT_MESSAGES = 20
    }
}
