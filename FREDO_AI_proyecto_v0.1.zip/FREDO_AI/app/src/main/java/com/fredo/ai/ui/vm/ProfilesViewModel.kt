package com.fredo.ai.ui.vm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fredo.ai.FredoApp
import com.fredo.ai.data.db.ProfileEntity
import com.fredo.ai.data.db.ProfileRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProfilesViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as FredoApp).container

    val profiles: StateFlow<List<ProfileEntity>> =
        c.profiles.profiles.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val active: StateFlow<ProfileEntity?> =
        c.profiles.activeProfile.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val unlockedId: StateFlow<Long?> = c.unlockedProfileId

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message
    fun clearMessage() { _message.value = null }

    /** Cambia de perfil; si el destino tiene PIN, exige haberlo verificado antes. */
    fun select(p: ProfileEntity, pin: String?, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = !p.hasPin() || (pin != null && c.profiles.verifyPin(p, pin))
            if (ok) {
                c.unlockedProfileId.value = p.id
                c.profiles.select(p.id)
            }
            onResult(ok)
        }
    }

    fun unlock(p: ProfileEntity, pin: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = c.profiles.verifyPin(p, pin)
            if (ok) c.unlockedProfileId.value = p.id
            onResult(ok)
        }
    }

    fun add(name: String, role: ProfileRole, instructions: String) {
        if (name.isBlank()) return
        viewModelScope.launch { c.profiles.add(name, role, instructions) }
    }

    fun saveEdits(p: ProfileEntity, name: String, instructions: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            c.profiles.update(p.copy(name = name.trim(), customInstructions = instructions.trim()))
        }
    }

    fun setPin(p: ProfileEntity, pin: String?) {
        viewModelScope.launch {
            c.profiles.setPin(p, pin)
            c.unlockedProfileId.value = p.id
            _message.value = if (pin.isNullOrEmpty()) "PIN quitado." else "PIN guardado."
        }
    }

    fun delete(p: ProfileEntity) {
        viewModelScope.launch {
            val ok = c.profiles.delete(p)
            _message.value = if (ok) "Perfil eliminado con sus mensajes y recuerdos." else "No se puede eliminar el último propietario."
        }
    }
}
