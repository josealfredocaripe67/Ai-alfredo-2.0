package com.fredo.ai.data.settings

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.fredoDataStore by preferencesDataStore(name = "fredo_settings")

enum class ProviderType(val label: String, val defaultBaseUrl: String, val defaultModel: String) {
    OPENAI_COMPATIBLE("OpenAI o compatible", "https://api.openai.com/v1", "gpt-4o-mini"),
    ANTHROPIC("Anthropic (Claude)", "https://api.anthropic.com", "claude-haiku-5-5"),
    GEMINI("Google Gemini", "https://generativelanguage.googleapis.com", "gemini-2.0-flash");

    companion object {
        fun from(name: String?): ProviderType = entries.firstOrNull { it.name == name } ?: OPENAI_COMPATIBLE
    }
}

enum class ThemeMode(val label: String) {
    DARK("Oscuro"),
    LIGHT("Claro (White Vision)"),
    SYSTEM("Seguir al sistema");

    companion object {
        fun from(name: String?): ThemeMode = entries.firstOrNull { it.name == name } ?: DARK
    }
}

data class AppSettings(
    val provider: ProviderType = ProviderType.OPENAI_COMPATIBLE,
    val baseUrl: String = ProviderType.OPENAI_COMPATIBLE.defaultBaseUrl,
    val model: String = ProviderType.OPENAI_COMPATIBLE.defaultModel,
    val themeMode: ThemeMode = ThemeMode.DARK,
    val activeProfileId: Long = 0L,
    val memoryEnabled: Boolean = true
)

class SettingsStore(context: Context) {
    private val ds = context.applicationContext.fredoDataStore

    private val kProvider = stringPreferencesKey("provider")
    private val kTheme = stringPreferencesKey("theme")
    private val kActiveProfile = longPreferencesKey("active_profile")
    private val kMemory = booleanPreferencesKey("memory_enabled")
    private fun kBase(t: ProviderType) = stringPreferencesKey("base_" + t.name)
    private fun kModel(t: ProviderType) = stringPreferencesKey("model_" + t.name)

    val settings: Flow<AppSettings> = ds.data.map { p: Preferences ->
        val type = ProviderType.from(p[kProvider])
        AppSettings(
            provider = type,
            baseUrl = p[kBase(type)] ?: type.defaultBaseUrl,
            model = p[kModel(type)] ?: type.defaultModel,
            themeMode = ThemeMode.from(p[kTheme]),
            activeProfileId = p[kActiveProfile] ?: 0L,
            memoryEnabled = p[kMemory] ?: true
        )
    }

    suspend fun setProvider(type: ProviderType) {
        ds.edit { it[kProvider] = type.name }
    }

    suspend fun setConnection(type: ProviderType, baseUrl: String, model: String) {
        ds.edit {
            it[kBase(type)] = baseUrl
            it[kModel(type)] = model
        }
    }

    suspend fun setTheme(mode: ThemeMode) {
        ds.edit { it[kTheme] = mode.name }
    }

    suspend fun setActiveProfile(id: Long) {
        ds.edit { it[kActiveProfile] = id }
    }

    suspend fun setMemoryEnabled(enabled: Boolean) {
        ds.edit { it[kMemory] = enabled }
    }
}
