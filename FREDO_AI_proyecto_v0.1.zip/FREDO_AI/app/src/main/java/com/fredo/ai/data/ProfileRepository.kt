package com.fredo.ai.data

import com.fredo.ai.data.db.MemoryDao
import com.fredo.ai.data.db.MessageDao
import com.fredo.ai.data.db.ProfileDao
import com.fredo.ai.data.db.ProfileEntity
import com.fredo.ai.data.db.ProfileRole
import com.fredo.ai.data.settings.SettingsStore
import com.fredo.ai.domain.PinHasher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class ProfileRepository(
    private val profileDao: ProfileDao,
    private val messageDao: MessageDao,
    private val memoryDao: MemoryDao,
    private val settings: SettingsStore
) {
    val profiles: Flow<List<ProfileEntity>> = profileDao.observeAll()

    val activeProfile: Flow<ProfileEntity?> = combine(
        profiles,
        settings.settings.map { it.activeProfileId }.distinctUntilChanged()
    ) { list, id -> list.firstOrNull { it.id == id } ?: list.firstOrNull() }

    suspend fun ensureDefault() {
        if (profileDao.count() == 0) {
            val id = profileDao.insert(ProfileEntity(name = "Alfredo", role = ProfileRole.OWNER.name))
            settings.setActiveProfile(id)
        }
    }

    suspend fun add(name: String, role: ProfileRole, instructions: String): Long =
        profileDao.insert(
            ProfileEntity(name = name.trim(), role = role.name, customInstructions = instructions.trim())
        )

    suspend fun update(profile: ProfileEntity) = profileDao.update(profile)

    suspend fun select(id: Long) = settings.setActiveProfile(id)

    /** Devuelve false si se intentó borrar el último propietario. */
    suspend fun delete(profile: ProfileEntity): Boolean {
        if (profile.isOwner() && profileDao.countByRole(ProfileRole.OWNER.name) <= 1) return false
        messageDao.clearProfile(profile.id)
        memoryDao.deleteForProfile(profile.id)
        profileDao.delete(profile.id)
        return true
    }

    suspend fun setPin(profile: ProfileEntity, pin: String?) {
        val updated = if (pin.isNullOrEmpty()) {
            profile.copy(pinHash = null, pinSalt = null)
        } else {
            val salt = PinHasher.newSalt()
            val hash = withContext(Dispatchers.Default) { PinHasher.hash(pin, salt) }
            profile.copy(pinHash = hash, pinSalt = salt)
        }
        profileDao.update(updated)
    }

    suspend fun verifyPin(profile: ProfileEntity, pin: String): Boolean {
        val salt = profile.pinSalt
        val hash = profile.pinHash
        if (salt == null || hash == null) return true
        return withContext(Dispatchers.Default) { PinHasher.verify(pin, salt, hash) }
    }
}
