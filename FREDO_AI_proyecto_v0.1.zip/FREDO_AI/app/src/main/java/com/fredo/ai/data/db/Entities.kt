package com.fredo.ai.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class ProfileRole(val label: String) {
    OWNER("Propietario"),
    FAMILY("Familiar");

    companion object {
        fun from(name: String?): ProfileRole = entries.firstOrNull { it.name == name } ?: FAMILY
    }
}

enum class EvidenceType(val label: String) {
    HECHO("Hecho explícito"),
    PATRON("Patrón observado"),
    HIPOTESIS("Hipótesis"),
    PREFERENCIA("Preferencia"),
    TEMPORAL("Dato temporal");

    companion object {
        fun from(name: String?): EvidenceType = entries.firstOrNull { it.name == name } ?: HIPOTESIS
    }
}

enum class MemoryStatus(val label: String) {
    PENDIENTE("Pendiente de validar"),
    CONFIRMADO("Confirmado"),
    CORREGIDO("Corregido"),
    RETIRADO("Retirado");

    companion object {
        fun from(name: String?): MemoryStatus = entries.firstOrNull { it.name == name } ?: PENDIENTE
    }
}

enum class Level(val label: String) {
    BAJA("Baja"),
    MEDIA("Media"),
    ALTA("Alta");

    companion object {
        fun from(name: String?): Level = entries.firstOrNull { it.name == name } ?: MEDIA
    }
}

@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val role: String,
    val customInstructions: String = "",
    val pinHash: String? = null,
    val pinSalt: String? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun isOwner(): Boolean = role == ProfileRole.OWNER.name
    fun hasPin(): Boolean = !pinHash.isNullOrEmpty() && !pinSalt.isNullOrEmpty()
}

@Entity(tableName = "messages", indices = [Index("profileId", "sessionId")])
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long,
    val sessionId: Long,
    val role: String, // "user" | "assistant"
    val content: String,
    val createdAt: Long = System.currentTimeMillis(),
    val isError: Boolean = false
)

/** Esquema de memoria de la guía maestra (sección 14). */
@Entity(tableName = "memories", indices = [Index("profileId")])
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long,
    val summary: String,
    val category: String,
    val source: String,
    val createdAt: Long = System.currentTimeMillis(),
    val evidenceType: String = EvidenceType.HIPOTESIS.name,
    val confidence: String = Level.MEDIA.name,
    val sensitivity: String = Level.MEDIA.name,
    val sharedWithFamily: Boolean = false,
    val reviewDate: Long? = null,
    val status: String = MemoryStatus.PENDIENTE.name
)
