package com.fredo.ai.data.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import javax.net.ssl.SSLException

internal object HttpJson {
    suspend fun post(url: String, headers: Map<String, String>, body: JSONObject): JSONObject =
        withContext(Dispatchers.IO) {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15_000
                    readTimeout = 90_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    for ((k, v) in headers) setRequestProperty(k, v)
                }
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code !in 200..299) {
                    throw AiException(kindFor(code), apiMessage(text, code))
                }
                try {
                    JSONObject(text)
                } catch (e: JSONException) {
                    throw AiException(AiException.Kind.PARSE, "respuesta no es JSON")
                }
            } catch (e: AiException) {
                throw e
            } catch (e: UnknownHostException) {
                throw AiException(AiException.Kind.NO_CONNECTION, "host desconocido")
            } catch (e: SocketTimeoutException) {
                throw AiException(AiException.Kind.TIMEOUT, "tiempo agotado")
            } catch (e: SSLException) {
                throw AiException(AiException.Kind.NO_CONNECTION, "error de conexión segura")
            } catch (e: IOException) {
                throw AiException(AiException.Kind.NO_CONNECTION, e.javaClass.simpleName)
            } finally {
                conn?.disconnect()
            }
        }

    private fun kindFor(code: Int): AiException.Kind = when (code) {
        401, 403 -> AiException.Kind.AUTH
        429 -> AiException.Kind.QUOTA
        400, 404, 422 -> AiException.Kind.BAD_REQUEST
        in 500..599 -> AiException.Kind.SERVER
        else -> AiException.Kind.UNKNOWN
    }

    /** Extrae un mensaje corto del error del proveedor, sin incluir datos de la solicitud. */
    private fun apiMessage(text: String, code: Int): String {
        val fromJson = try {
            val root = JSONObject(text)
            val err = root.opt("error")
            when (err) {
                is JSONObject -> err.optString("message")
                is String -> err
                else -> root.optString("message")
            }
        } catch (e: Exception) {
            ""
        }
        val msg = if (fromJson.isNullOrBlank()) "HTTP $code" else fromJson
        return msg.take(200)
    }
}
