package com.fredo.ai

import android.app.Application
import com.fredo.ai.di.AppContainer

class FredoApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
