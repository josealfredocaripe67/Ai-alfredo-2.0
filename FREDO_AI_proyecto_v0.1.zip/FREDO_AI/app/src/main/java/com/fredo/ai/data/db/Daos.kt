package com.fredo.ai.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profiles ORDER BY id")
    fun observeAll(): Flow<List<ProfileEntity>>

    @Query("SELECT * FROM profiles WHERE id = :id")
    suspend fun get(id: Long): ProfileEntity?

    @Query("SELECT COUNT(*) FROM profiles")
    suspend fun count(): Int

    @Query("SELECT COUNT(*) FROM profiles WHERE role = :role")
    suspend fun countByRole(role: String): Int

    @Query("SELECT id FROM profiles WHERE role = 'OWNER' ORDER BY id LIMIT 1")
    suspend fun firstOwnerId(): Long?

    @Insert
    suspend fun insert(profile: ProfileEntity): Long

    @Update
    suspend fun update(profile: ProfileEntity)

    @Query("DELETE FROM profiles WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE profileId = :profileId AND sessionId = :sessionId ORDER BY id")
    fun observe(profileId: Long, sessionId: Long): Flow<List<MessageEntity>>

    @Query(
        "SELECT * FROM messages WHERE profileId = :profileId AND sessionId = :sessionId " +
            "AND isError = 0 ORDER BY id DESC LIMIT :limit"
    )
    suspend fun lastForContext(profileId: Long, sessionId: Long, limit: Int): List<MessageEntity>

    @Query("SELECT MAX(sessionId) FROM messages WHERE profileId = :profileId")
    suspend fun latestSession(profileId: Long): Long?

    @Insert
    suspend fun insert(message: MessageEntity): Long

    @Query("DELETE FROM messages WHERE profileId = :profileId")
    suspend fun clearProfile(profileId: Long)

    @Query("SELECT COUNT(*) FROM messages")
    suspend fun count(): Int
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories WHERE profileId = :profileId ORDER BY createdAt DESC, id DESC")
    fun observeForProfile(profileId: Long): Flow<List<MemoryEntity>>

    /** Recuerdos propios del perfil + los que el propietario marcó como compartibles con familiares. */
    @Query(
        "SELECT * FROM memories WHERE status != 'RETIRADO' AND " +
            "(profileId = :profileId OR (sharedWithFamily = 1 AND sensitivity != 'ALTA' AND profileId = :ownerId))"
    )
    suspend fun candidates(profileId: Long, ownerId: Long): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE profileId = :profileId ORDER BY id")
    suspend fun allForProfile(profileId: Long): List<MemoryEntity>

    @Insert
    suspend fun insert(memory: MemoryEntity): Long

    @Insert
    suspend fun insertAll(memories: List<MemoryEntity>)

    @Update
    suspend fun update(memory: MemoryEntity)

    @Query("DELETE FROM memories WHERE id = :id AND profileId = :profileId")
    suspend fun delete(id: Long, profileId: Long)

    @Query("DELETE FROM memories WHERE profileId = :profileId")
    suspend fun deleteForProfile(profileId: Long)

    @Query("UPDATE memories SET status = 'CONFIRMADO' WHERE profileId = :profileId AND status = 'PENDIENTE'")
    suspend fun confirmAllPending(profileId: Long): Int

    @Query("SELECT COUNT(*) FROM memories")
    suspend fun count(): Int
}
