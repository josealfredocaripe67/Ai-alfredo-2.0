package com.fredo.ai.data

import android.content.ContentResolver
import android.net.Uri
import com.fredo.ai.data.db.MemoryDao
import com.fredo.ai.data.db.MemoryEntity
import com.fredo.ai.data.db.ProfileDao
import com.fredo.ai.data.memory.ProfileImporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class ImportSummary(val added: Int, val skipped: Int)

class MemoryRepository(
    private val dao: MemoryDao,
    private val profileDao: ProfileDao,
    private val resolver: ContentResolver
) {
    fun observe(profileId: Long): Flow<List<MemoryEntity>> = dao.observeForProfile(profileId)

    suspend fun add(memory: MemoryEntity) = dao.insert(memory)
    suspend fun update(memory: MemoryEntity) = dao.update(memory)
    suspend fun delete(memory: MemoryEntity) = dao.delete(memory.id, memory.profileId)
    suspend fun confirmAllPending(profileId: Long): Int = dao.confirmAllPending(profileId)

    /** Exporta la memoria del perfil a un JSON legible (copia de seguridad). */
    suspend fun exportJson(profileId: Long, uri: Uri): Int = withContext(Dispatchers.IO) {
        val items = dao.allForProfile(profileId)
        val arr = JSONArray()
        for (m in items) {
            arr.put(
                JSONObject()
                    .put("id", m.id)
                    .put("summary", m.summary)
                    .put("category", m.category)
                    .put("source", m.source)
                    .put("date", m.createdAt)
                    .put("evidence_type", m.evidenceType)
                    .put("confidence", m.confidence)
                    .put("sensitivity", m.sensitivity)
                    .put("shared_with_family", m.sharedWithFamily)
                    .put("review_date", m.reviewDate ?: JSONObject.NULL)
                    .put("status", m.status)
            )
        }
        val root = JSONObject().put("fredo_memory_export", 1).put("items", arr)
        resolver.openOutputStream(uri, "wt")?.use {
            it.write(root.toString(2).toByteArray(Charsets.UTF_8))
        } ?: throw IllegalStateException("No se pudo abrir el archivo de destino")
        items.size
    }

    /** Importa perfil_inicial.json como recuerdos pendientes de validar, sin duplicar. */
    suspend fun importProfileJson(profileId: Long, uri: Uri): ImportSummary = withContext(Dispatchers.IO) {
        val text = resolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            ?: throw IllegalStateException("No se pudo leer el archivo")
        val parsed = ProfileImporter.parse(text, profileId)
        val existing = dao.allForProfile(profileId).map { it.summary }.toSet()
        val fresh = parsed.memories.filter { it.summary !in existing }
        dao.insertAll(fresh)
        val profile = profileDao.get(profileId)
        if (profile != null && profile.customInstructions.isBlank() && parsed.customInstructions.isNotBlank()) {
            profileDao.update(profile.copy(customInstructions = parsed.customInstructions))
        }
        ImportSummary(added = fresh.size, skipped = parsed.memories.size - fresh.size)
    }
}
