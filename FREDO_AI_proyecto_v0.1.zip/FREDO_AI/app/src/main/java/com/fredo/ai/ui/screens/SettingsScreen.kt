package com.fredo.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.fredo.ai.data.settings.ProviderType
import com.fredo.ai.data.settings.ThemeMode
import com.fredo.ai.ui.components.ScreenTitle
import com.fredo.ai.ui.components.SectionLabel
import com.fredo.ai.ui.vm.SettingsViewModel
import com.fredo.ai.ui.vm.TestState

@Composable
fun SettingsScreen(vm: SettingsViewModel = viewModel()) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val hasKey by vm.hasKey.collectAsStateWithLifecycle()
    val test by vm.test.collectAsStateWithLifecycle()
    val counts by vm.counts.collectAsStateWithLifecycle()
    val saved by vm.saved.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var baseUrl by remember(s.provider, s.baseUrl) { mutableStateOf(s.baseUrl) }
    var model by remember(s.provider, s.model) { mutableStateOf(s.model) }
    var newKey by remember(s.provider) { mutableStateOf("") }
    var showKey by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { vm.refresh() }
    LaunchedEffect(saved) {
        if (saved) {
            newKey = ""
            vm.clearSaved()
            vm.refresh()
        }
    }

    val versionName = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "?"
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenTitle("Ajustes")
        Column(Modifier.padding(horizontal = 16.dp)) {
            SectionLabel("Proveedor de IA")
            for (type in ProviderType.entries) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = s.provider == type, onClick = { vm.selectProvider(type) })
                    Text(type.label)
                }
            }
            OutlinedTextField(
                baseUrl, { baseUrl = it }, label = { Text("Dirección del servicio (https)") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                model, { model = it }, label = { Text("Modelo") },
                supportingText = { Text("Los nombres de modelo cambian con el tiempo; si falla, revisa el nombre en la documentación del proveedor.") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                newKey, { newKey = it },
                label = { Text(if (hasKey) "Clave API (guardada; escribe una nueva para reemplazarla)" else "Clave API") },
                singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Ocultar" else "Mostrar") }
                if (hasKey) TextButton(onClick = { vm.deleteKey(s.provider) }) { Text("Borrar clave guardada") }
            }
            Text(
                if (hasKey) "Hay una clave guardada, cifrada con Android Keystore en este teléfono."
                else "No hay clave guardada para este proveedor. La clave nunca se incluye en el APK ni en el código.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.saveConnection(s.provider, baseUrl, model, newKey) }) { Text("Guardar") }
                OutlinedButton(onClick = { vm.runTest() }, enabled = test != TestState.Running) { Text("Probar conexión") }
            }
            when (val t = test) {
                TestState.Idle -> {}
                TestState.Running -> Text("Probando…", Modifier.padding(top = 8.dp))
                is TestState.Done -> Text(
                    (if (t.result.ok) "✔ " else "✖ ") + t.result.message + " (${t.result.millis} ms)",
                    Modifier.padding(top = 8.dp),
                    color = if (t.result.ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
            }
            Text(
                "Recuerda pulsar «Guardar» antes de probar si cambiaste algo.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            SectionLabel("Apariencia")
            for (mode in ThemeMode.entries) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = s.themeMode == mode, onClick = { vm.setTheme(mode) })
                    Text(mode.label)
                }
            }

            SectionLabel("Memoria")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = s.memoryEnabled, onCheckedChange = { vm.setMemoryEnabled(it) })
                Text("  Usar la memoria en las respuestas")
            }
            Text(
                "Si la apagas, no se envía ningún recuerdo al proveedor. El historial reciente de la conversación sí se envía para que pueda responder.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            SectionLabel("Diagnóstico")
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Versión de la app: $versionName", style = MaterialTheme.typography.bodySmall)
                    Text("Proveedor activo: ${s.provider.label}", style = MaterialTheme.typography.bodySmall)
                    Text("Modelo configurado: ${s.model}", style = MaterialTheme.typography.bodySmall)
                    Text("Clave guardada: ${if (hasKey) "sí" else "no"}", style = MaterialTheme.typography.bodySmall)
                    Text("Mensajes guardados: ${counts.messages} · Recuerdos: ${counts.memories}", style = MaterialTheme.typography.bodySmall)
                }
            }

            SectionLabel("Estado de las funciones")
            Text(
                "Chat con proveedor configurable, memoria revisable, perfiles con PIN opcional, tema oscuro/claro y diagnóstico: implementados en el código (ver docs/ESTADO_DE_FUNCIONES.md para lo que está probado y lo que no).\n\n" +
                    "Pendientes, NO disponibles todavía: búsqueda web con fuentes, voz, importación de documentos y de chats, respuestas en streaming, modo educativo dedicado.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}
