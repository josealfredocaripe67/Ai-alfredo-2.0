package com.fredo.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.fredo.ai.data.settings.ThemeMode

object FredoColors {
    val Black = Color(0xFF000000)
    val Panel = Color(0xFF10141B)
    val PanelHigh = Color(0xFF1A2030)
    val Silver = Color(0xFFC3CAD6)
    val SilverDim = Color(0xFF8A93A3)
    val Blue = Color(0xFF3B82F6)
    val BlueGlow = Color(0xFF7DB3FF)
    val BlueDeep = Color(0xFF1F5FD9)
    val White = Color(0xFFFFFFFF)
    val Danger = Color(0xFFFF6B6B)
}

private val DarkScheme = darkColorScheme(
    primary = FredoColors.Blue,
    onPrimary = FredoColors.White,
    secondary = FredoColors.Silver,
    onSecondary = FredoColors.Black,
    background = FredoColors.Black,
    onBackground = FredoColors.White,
    surface = FredoColors.Panel,
    onSurface = FredoColors.White,
    surfaceVariant = FredoColors.PanelHigh,
    onSurfaceVariant = FredoColors.Silver,
    outline = FredoColors.SilverDim,
    error = FredoColors.Danger
)

private val LightScheme = lightColorScheme(
    primary = FredoColors.BlueDeep,
    onPrimary = FredoColors.White,
    secondary = Color(0xFF4A5363),
    onSecondary = FredoColors.White,
    background = Color(0xFFF7F9FC),
    onBackground = Color(0xFF0B0F17),
    surface = FredoColors.White,
    onSurface = Color(0xFF0B0F17),
    surfaceVariant = Color(0xFFE8ECF3),
    onSurfaceVariant = Color(0xFF4A5363),
    outline = Color(0xFF8A93A3),
    error = Color(0xFFC62828)
)

@Composable
fun FredoTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, content = content)
}
