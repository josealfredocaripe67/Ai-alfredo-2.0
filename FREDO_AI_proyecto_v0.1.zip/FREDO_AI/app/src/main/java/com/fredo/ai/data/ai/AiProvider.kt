package com.fredo.ai.data.ai

import com.fredo.ai.data.settings.ProviderType

data class ChatTurn(val role: String, val content: String) {
    companion object {
        const val USER = "user"
        const val ASSISTANT = "assistant"
    }
}

class AiException(val kind: Kind, message: String) : Exception(message) {
    enum class Kind { NO_KEY, NO_CONNECTION, TIMEOUT, AUTH, QUOTA, BAD_REQUEST, SERVER, PARSE, UNKNOWN }

    /** Mensaje comprensible para la persona, en español. */
    fun userMessage(): String = when (kind) {
        Kind.NO_KEY -> "Falta la clave API. Ve a Ajustes, elige un proveedor y guarda tu clave."
        Kind.NO_CONNECTION -> "No hay conexión con el servidor. Revisa tu Internet y la dirección del proveedor en Ajustes."
        Kind.TIMEOUT -> "El proveedor tardó demasiado en responder. Inténtalo de nuevo en un momento."
        Kind.AUTH -> "El proveedor rechazó la clave (error de autenticación). Revisa que la clave sea correcta y esté activa."
        Kind.QUOTA -> "Se alcanzó el límite de uso o de cuota del proveedor. Espera un poco o revisa tu plan y saldo."
        Kind.BAD_REQUEST -> "El proveedor no aceptó la solicitud. Revisa el nombre del modelo en Ajustes. Detalle: " + (message ?: "")
        Kind.SERVER -> "El proveedor tiene un problema temporal (error de servidor). Inténtalo más tarde."
        Kind.PARSE -> "No pude entender la respuesta del proveedor. Comprueba que la dirección y el tipo de proveedor sean los correctos."
        Kind.UNKNOWN -> "Ocurrió un error inesperado: " + (message ?: "sin detalle")
    }
}

/** Interfaz común: cualquier proveedor se puede intercambiar sin tocar el resto de la app. */
interface AiProvider {
    suspend fun complete(system: String, turns: List<ChatTurn>): String
}

object AiProviderFactory {
    fun create(type: ProviderType, baseUrl: String, model: String, apiKey: String?): AiProvider {
        if (apiKey.isNullOrBlank()) throw AiException(AiException.Kind.NO_KEY, "sin clave")
        val url = baseUrl.trim().trimEnd('/')
        if (!url.startsWith("https://")) {
            throw AiException(
                AiException.Kind.BAD_REQUEST,
                "la dirección debe empezar por https:// (las conexiones sin cifrar están bloqueadas)"
            )
        }
        val cleanModel = model.trim()
        if (cleanModel.isEmpty()) throw AiException(AiException.Kind.BAD_REQUEST, "falta el nombre del modelo")
        return when (type) {
            ProviderType.OPENAI_COMPATIBLE -> OpenAiCompatibleProvider(url, cleanModel, apiKey.trim())
            ProviderType.ANTHROPIC -> AnthropicProvider(url, cleanModel, apiKey.trim())
            ProviderType.GEMINI -> GeminiProvider(url, cleanModel, apiKey.trim())
        }
    }
}

/**
 * Asegura una conversación válida para todos los proveedores: empieza con el usuario
 * y los mensajes consecutivos del mismo rol se fusionan.
 */
internal fun normalizeTurns(turns: List<ChatTurn>): List<ChatTurn> {
    val out = ArrayList<ChatTurn>()
    for (t in turns) {
        if (t.content.isBlank()) continue
        val last = out.lastOrNull()
        if (last != null && last.role == t.role) {
            out[out.size - 1] = ChatTurn(last.role, last.content + "\n\n" + t.content)
        } else {
            out.add(t)
        }
    }
    while (out.isNotEmpty() && out.first().role != ChatTurn.USER) out.removeAt(0)
    return out
}
