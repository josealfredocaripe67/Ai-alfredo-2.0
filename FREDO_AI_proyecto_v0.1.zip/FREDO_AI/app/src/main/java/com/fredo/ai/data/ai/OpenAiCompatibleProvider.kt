package com.fredo.ai.data.ai

import org.json.JSONArray
import org.json.JSONObject

/** Sirve para OpenAI y para cualquier servicio con la misma API (OpenRouter, Groq, etc.). */
class OpenAiCompatibleProvider(
    private val baseUrl: String,
    private val model: String,
    private val apiKey: String
) : AiProvider {

    override suspend fun complete(system: String, turns: List<ChatTurn>): String {
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", system))
        for (t in normalizeTurns(turns)) {
            messages.put(JSONObject().put("role", t.role).put("content", t.content))
        }
        val body = JSONObject().put("model", model).put("messages", messages)
        val json = HttpJson.post(
            url = "$baseUrl/chat/completions",
            headers = mapOf("Authorization" to "Bearer $apiKey"),
            body = body
        )
        val message = json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
        // org.json devuelve la cadena "null" para valores null; se trata como vacío.
        val text = if (message == null || message.isNull("content")) "" else message.optString("content")
        if (text.isBlank()) throw AiException(AiException.Kind.PARSE, "respuesta vacía")
        return text.trim()
    }
}
