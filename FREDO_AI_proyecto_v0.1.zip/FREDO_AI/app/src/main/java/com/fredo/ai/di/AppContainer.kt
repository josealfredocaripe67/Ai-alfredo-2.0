package com.fredo.ai.di

import android.content.Context
import androidx.room.Room
import com.fredo.ai.data.ChatRepository
import com.fredo.ai.data.MemoryRepository
import com.fredo.ai.data.ProfileRepository
import com.fredo.ai.data.db.FredoDatabase
import com.fredo.ai.data.settings.SecureKeyStore
import com.fredo.ai.data.settings.SettingsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/** Contenedor manual de dependencias (suficiente para esta app, sin librerías extra). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val db: FredoDatabase = Room.databaseBuilder(appContext, FredoDatabase::class.java, "fredo.db").build()
    val settings = SettingsStore(appContext)
    val keys = SecureKeyStore(appContext)
    val profiles = ProfileRepository(db.profileDao(), db.messageDao(), db.memoryDao(), settings)
    val memory = MemoryRepository(db.memoryDao(), db.profileDao(), appContext.contentResolver)
    val chat = ChatRepository(db, settings, keys)

    /** Perfil desbloqueado en esta sesión (en memoria; se pierde al cerrar la app). */
    val unlockedProfileId = MutableStateFlow<Long?>(null)

    init {
        appScope.launch { profiles.ensureDefault() }
    }
}
