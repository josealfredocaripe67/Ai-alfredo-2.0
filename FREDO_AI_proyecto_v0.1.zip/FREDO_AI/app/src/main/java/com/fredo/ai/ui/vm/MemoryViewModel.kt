package com.fredo.ai.ui.vm

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fredo.ai.FredoApp
import com.fredo.ai.data.db.EvidenceType
import com.fredo.ai.data.db.Level
import com.fredo.ai.data.db.MemoryEntity
import com.fredo.ai.data.db.MemoryStatus
import com.fredo.ai.data.db.ProfileEntity
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class MemoryViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as FredoApp).container

    val profile: StateFlow<ProfileEntity?> =
        c.profiles.activeProfile.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val items: StateFlow<List<MemoryEntity>> =
        c.profiles.activeProfile
            .flatMapLatest { p -> if (p == null) flowOf(emptyList<MemoryEntity>()) else c.memory.observe(p.id) }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message
    fun clearMessage() { _message.value = null }

    private suspend fun activeId(): Long? = c.profiles.activeProfile.first()?.id

    fun save(existing: MemoryEntity?, summary: String, category: String, type: EvidenceType,
             confidence: Level, sensitivity: Level, status: MemoryStatus, shared: Boolean) {
        val text = summary.trim()
        if (text.isEmpty()) return
        viewModelScope.launch {
            val pid = activeId() ?: return@launch
            if (existing == null) {
                c.memory.add(
                    MemoryEntity(
                        profileId = pid, summary = text, category = category.trim().ifEmpty { "general" },
                        source = "escrito por la persona en la app", evidenceType = type.name,
                        confidence = confidence.name, sensitivity = sensitivity.name,
                        sharedWithFamily = shared, status = status.name
                    )
                )
            } else {
                // Si el texto cambió y seguía "confirmado", pasa a "corregido".
                val newStatus = if (text != existing.summary && status == MemoryStatus.CONFIRMADO) MemoryStatus.CORREGIDO else status
                c.memory.update(
                    existing.copy(
                        summary = text, category = category.trim().ifEmpty { "general" },
                        evidenceType = type.name, confidence = confidence.name,
                        sensitivity = sensitivity.name, sharedWithFamily = shared, status = newStatus.name
                    )
                )
            }
        }
    }

    fun setStatus(m: MemoryEntity, status: MemoryStatus) {
        viewModelScope.launch { c.memory.update(m.copy(status = status.name)) }
    }

    fun delete(m: MemoryEntity) {
        viewModelScope.launch { c.memory.delete(m) }
    }

    fun confirmAllPending() {
        viewModelScope.launch {
            val pid = activeId() ?: return@launch
            val n = c.memory.confirmAllPending(pid)
            _message.value = if (n == 0) "No había recuerdos pendientes." else "$n recuerdos marcados como confirmados."
        }
    }

    fun importProfile(uri: Uri) {
        viewModelScope.launch {
            val pid = activeId() ?: return@launch
            _message.value = try {
                val r = c.memory.importProfileJson(pid, uri)
                "Importado: ${r.added} recuerdos nuevos (${r.skipped} ya existían). Todos quedan pendientes de validar."
            } catch (e: Exception) {
                "No pude importar el archivo. ¿Es el perfil_inicial.json correcto? (${e.javaClass.simpleName})"
            }
        }
    }

    fun export(uri: Uri) {
        viewModelScope.launch {
            val pid = activeId() ?: return@launch
            _message.value = try {
                val n = c.memory.exportJson(pid, uri)
                "Exportados $n recuerdos. Guarda el archivo en un lugar privado."
            } catch (e: Exception) {
                "No pude exportar la memoria (${e.javaClass.simpleName})."
            }
        }
    }
}
