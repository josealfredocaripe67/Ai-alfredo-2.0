package com.fredo.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.fredo.ai.data.db.ProfileEntity
import com.fredo.ai.data.db.ProfileRole
import com.fredo.ai.ui.components.EnumDropdown
import com.fredo.ai.ui.components.ScreenTitle
import com.fredo.ai.ui.vm.ProfilesViewModel

@Composable
fun ProfilesScreen(vm: ProfilesViewModel = viewModel()) {
    val profiles by vm.profiles.collectAsStateWithLifecycle()
    val active by vm.active.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    var creating by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<ProfileEntity?>(null) }
    var pinFor by remember { mutableStateOf<ProfileEntity?>(null) }
    var switchTo by remember { mutableStateOf<ProfileEntity?>(null) }
    var deleting by remember { mutableStateOf<ProfileEntity?>(null) }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle(
            "Perfiles",
            "Cada perfil tiene su propio historial y sus propios recuerdos. El PIN es un candado sencillo, no cifra los datos."
        )
        Column(Modifier.padding(horizontal = 16.dp)) {
            Button(onClick = { creating = true }) { Text("Añadir perfil") }
            message?.let { msg ->
                Card(
                    Modifier.padding(top = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(msg, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { vm.clearMessage() }) { Text("OK") }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(profiles, key = { it.id }) { p ->
                val isActive = p.id == active?.id
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(p.name + if (isActive) "  ·  activo" else "", style = MaterialTheme.typography.titleMedium)
                        Text(
                            ProfileRole.from(p.role).label + if (p.hasPin()) " · protegido con PIN" else " · sin PIN",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row {
                            if (!isActive) {
                                TextButton(onClick = { if (p.hasPin()) switchTo = p else vm.select(p, null) {} }) { Text("Usar") }
                            }
                            TextButton(onClick = { editing = p }) { Text("Editar") }
                            TextButton(onClick = { pinFor = p }) { Text("PIN") }
                            TextButton(onClick = { deleting = p }) { Text("Eliminar") }
                        }
                    }
                }
            }
        }
    }

    if (creating) {
        var name by remember { mutableStateOf("") }
        var role by remember { mutableStateOf(ProfileRole.FAMILY) }
        var notes by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { creating = false },
            title = { Text("Nuevo perfil") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, singleLine = true)
                    EnumDropdown("Rol", role, ProfileRole.entries.toList(), { it.label }, { role = it })
                    OutlinedTextField(
                        notes, { notes = it },
                        label = { Text("Cómo prefiere que le hablen (opcional)") }, minLines = 2
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.add(name, role, notes); creating = false }, enabled = name.isNotBlank()) { Text("Crear") }
            },
            dismissButton = { TextButton(onClick = { creating = false }) { Text("Cancelar") } }
        )
    }

    editing?.let { p ->
        var name by remember(p.id) { mutableStateOf(p.name) }
        var notes by remember(p.id) { mutableStateOf(p.customInstructions) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Editar perfil") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, singleLine = true)
                    OutlinedTextField(
                        notes, { notes = it },
                        label = { Text("Instrucciones personalizadas") }, minLines = 4
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.saveEdits(p, name, notes); editing = null }, enabled = name.isNotBlank()) { Text("Guardar") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancelar") } }
        )
    }

    pinFor?.let { p ->
        var pin by remember(p.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pinFor = null },
            title = { Text("PIN de ${p.name}") },
            text = {
                Column {
                    OutlinedTextField(
                        pin, { pin = it.filter { c -> c.isDigit() }.take(8) },
                        label = { Text("Nuevo PIN (4 a 8 dígitos)") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                    )
                    if (p.hasPin()) {
                        TextButton(onClick = { vm.setPin(p, null); pinFor = null }) { Text("Quitar PIN") }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.setPin(p, pin); pinFor = null }, enabled = pin.length >= 4) { Text("Guardar") }
            },
            dismissButton = { TextButton(onClick = { pinFor = null }) { Text("Cancelar") } }
        )
    }

    switchTo?.let { p ->
        var pin by remember(p.id) { mutableStateOf("") }
        var wrong by remember(p.id) { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { switchTo = null },
            title = { Text("PIN de ${p.name}") },
            text = {
                Column {
                    OutlinedTextField(
                        pin, { pin = it.filter { c -> c.isDigit() }.take(8); wrong = false },
                        label = { Text("PIN") }, singleLine = true, isError = wrong,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                    )
                    if (wrong) Text("PIN incorrecto.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { vm.select(p, pin) { ok -> if (ok) switchTo = null else wrong = true } },
                    enabled = pin.length >= 4
                ) { Text("Entrar") }
            },
            dismissButton = { TextButton(onClick = { switchTo = null }) { Text("Cancelar") } }
        )
    }

    deleting?.let { p ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("¿Eliminar a ${p.name}?") },
            text = { Text("Se borrarán también su historial y sus recuerdos. No se puede deshacer.") },
            confirmButton = { TextButton(onClick = { vm.delete(p); deleting = null }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancelar") } }
        )
    }
}
