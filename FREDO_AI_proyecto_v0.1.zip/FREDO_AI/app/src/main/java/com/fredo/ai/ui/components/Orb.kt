package com.fredo.ai.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.fredo.ai.ui.theme.FredoColors

/** Esfera luminosa: identidad visual de FREDO AI. Pulsa más rápido mientras "piensa". */
@Composable
fun GlowingOrb(modifier: Modifier = Modifier, orbSize: Dp = 120.dp, active: Boolean = false) {
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (active) 800 else 2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val halo: Color = if (dark) FredoColors.BlueGlow else FredoColors.BlueDeep
    val core: Color = if (dark) FredoColors.White else FredoColors.BlueGlow

    Canvas(modifier = modifier.size(orbSize)) {
        val radius = this.size.minDimension / 2f
        val c = center
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(halo.copy(alpha = 0.55f), halo.copy(alpha = 0f)),
                center = c,
                radius = radius
            ),
            radius = radius,
            center = c
        )
        val bodyRadius = radius * 0.5f * pulse
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(core, FredoColors.BlueGlow, FredoColors.BlueDeep),
                center = Offset(c.x - bodyRadius * 0.25f, c.y - bodyRadius * 0.3f),
                radius = bodyRadius * 1.3f
            ),
            radius = bodyRadius,
            center = c
        )
        drawCircle(
            color = FredoColors.Silver.copy(alpha = 0.6f),
            radius = radius * 0.58f * pulse,
            center = c,
            style = Stroke(width = 1.5.dp.toPx())
        )
    }
}
