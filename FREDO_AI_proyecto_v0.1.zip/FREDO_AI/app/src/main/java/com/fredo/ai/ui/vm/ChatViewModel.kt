package com.fredo.ai.ui.vm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fredo.ai.FredoApp
import com.fredo.ai.data.ai.AiException
import com.fredo.ai.data.db.MessageEntity
import com.fredo.ai.data.db.ProfileEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as FredoApp).container

    /** Sesión elegida con "Nueva conversación": (perfil, sesión). */
    private val sessionOverride = MutableStateFlow<Pair<Long, Long>?>(null)

    val profile: StateFlow<ProfileEntity?> =
        c.profiles.activeProfile.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val messages: StateFlow<List<MessageEntity>> =
        combine(c.profiles.activeProfile, sessionOverride) { p, o -> Pair(p, o) }
            .flatMapLatest { (p, o) ->
                if (p == null) {
                    flowOf(emptyList<MessageEntity>())
                } else {
                    val sid = if (o != null && o.first == p.id) o.second else c.chat.latestSession(p.id)
                    c.chat.observe(p.id, sid)
                }
            }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _sending = MutableStateFlow(false)
    val sending: StateFlow<Boolean> = _sending

    private val _hasKey = MutableStateFlow(true)
    val hasKey: StateFlow<Boolean> = _hasKey

    fun refreshKeyState() {
        viewModelScope.launch {
            val type = c.settings.settings.first().provider
            _hasKey.value = c.keys.has(type)
        }
    }

    private suspend fun resolveSession(p: ProfileEntity): Long {
        val o = sessionOverride.value
        return if (o != null && o.first == p.id) o.second else c.chat.latestSession(p.id)
    }

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty() || _sending.value) return
        viewModelScope.launch {
            val p = c.profiles.activeProfile.first() ?: return@launch
            val sid = resolveSession(p)
            _sending.value = true
            try {
                c.chat.addUser(p.id, sid, clean)
                try {
                    val reply = c.chat.reply(p, sid, clean)
                    c.chat.addAssistant(p.id, sid, reply)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: AiException) {
                    c.chat.addError(p.id, sid, e.userMessage())
                } catch (e: Exception) {
                    c.chat.addError(p.id, sid, "Error inesperado (${e.javaClass.simpleName}). Inténtalo de nuevo.")
                }
            } finally {
                _sending.value = false
            }
        }
    }

    fun newConversation() {
        viewModelScope.launch {
            val p = c.profiles.activeProfile.first() ?: return@launch
            sessionOverride.value = Pair(p.id, System.currentTimeMillis())
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            val p = c.profiles.activeProfile.first() ?: return@launch
            c.chat.clearHistory(p.id)
            sessionOverride.value = null
        }
    }
}
