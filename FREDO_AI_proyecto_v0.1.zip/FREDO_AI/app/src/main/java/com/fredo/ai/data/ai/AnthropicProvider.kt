package com.fredo.ai.data.ai

import org.json.JSONArray
import org.json.JSONObject

class AnthropicProvider(
    private val baseUrl: String,
    private val model: String,
    private val apiKey: String
) : AiProvider {

    override suspend fun complete(system: String, turns: List<ChatTurn>): String {
        val messages = JSONArray()
        for (t in normalizeTurns(turns)) {
            messages.put(JSONObject().put("role", t.role).put("content", t.content))
        }
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 2048)
            .put("system", system)
            .put("messages", messages)
        val json = HttpJson.post(
            url = "$baseUrl/v1/messages",
            headers = mapOf("x-api-key" to apiKey, "anthropic-version" to "2023-06-01"),
            body = body
        )
        val content = json.optJSONArray("content")
        val sb = StringBuilder()
        if (content != null) {
            for (i in 0 until content.length()) {
                val block = content.optJSONObject(i) ?: continue
                if (block.optString("type") == "text") sb.append(block.optString("text"))
            }
        }
        if (sb.isBlank()) throw AiException(AiException.Kind.PARSE, "respuesta vacía")
        return sb.toString().trim()
    }
}
