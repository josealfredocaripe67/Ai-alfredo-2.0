package com.fredo.ai.data.ai

import org.json.JSONArray
import org.json.JSONObject

class GeminiProvider(
    private val baseUrl: String,
    private val model: String,
    private val apiKey: String
) : AiProvider {

    override suspend fun complete(system: String, turns: List<ChatTurn>): String {
        val contents = JSONArray()
        for (t in normalizeTurns(turns)) {
            val role = if (t.role == ChatTurn.ASSISTANT) "model" else "user"
            contents.put(
                JSONObject().put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", t.content)))
            )
        }
        val body = JSONObject()
            .put(
                "system_instruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
            )
            .put("contents", contents)
        val json = HttpJson.post(
            url = "$baseUrl/v1beta/models/$model:generateContent",
            headers = mapOf("x-goog-api-key" to apiKey),
            body = body
        )
        val candidate = json.optJSONArray("candidates")?.optJSONObject(0)
        val parts = candidate?.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text").orEmpty())
        }
        if (sb.isBlank()) {
            val blocked = json.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            val detail = if (blocked.isNotEmpty()) "bloqueado por el proveedor ($blocked)" else "respuesta vacía"
            throw AiException(AiException.Kind.PARSE, detail)
        }
        return sb.toString().trim()
    }
}
