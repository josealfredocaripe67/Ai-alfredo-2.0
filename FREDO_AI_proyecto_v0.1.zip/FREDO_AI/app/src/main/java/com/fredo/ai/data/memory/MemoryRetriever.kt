package com.fredo.ai.data.memory

import com.fredo.ai.data.db.EvidenceType
import com.fredo.ai.data.db.MemoryEntity
import com.fredo.ai.data.db.MemoryStatus

/**
 * Recupera solo el contexto mínimo pertinente (guía maestra, sección 14): no se envía toda la
 * memoria al proveedor, solo las entradas que comparten palabras con el mensaje y las
 * preferencias de comunicación confirmadas.
 */
object MemoryRetriever {
    private val stopWords = setOf(
        "de", "la", "el", "en", "y", "a", "que", "los", "las", "un", "una", "por", "con", "para",
        "es", "se", "del", "al", "lo", "mi", "me", "te", "tu", "su", "como", "pero", "más", "mas"
    )

    fun tokens(text: String): Set<String> =
        text.lowercase()
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length > 2 && it !in stopWords }
            .toSet()

    fun select(query: String, items: List<MemoryEntity>, limit: Int = 8): List<MemoryEntity> {
        val q = tokens(query)
        val scored = items
            .filter { it.status != MemoryStatus.RETIRADO.name }
            .map { m ->
                val overlap = tokens(m.summary + " " + m.category).count { it in q }
                val isPreference = m.evidenceType == EvidenceType.PREFERENCIA.name
                val confirmedBonus =
                    if (m.status == MemoryStatus.CONFIRMADO.name || m.status == MemoryStatus.CORREGIDO.name) 1 else 0
                Triple(m, overlap, overlap * 3 + confirmedBonus + (if (isPreference) 1 else 0))
            }
            .filter { (m, overlap, _) -> overlap > 0 || m.evidenceType == EvidenceType.PREFERENCIA.name }
        return scored.sortedByDescending { it.third }.take(limit).map { it.first }
    }
}
