package com.fredo.ai.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.fredo.ai.data.db.EvidenceType
import com.fredo.ai.data.db.Level
import com.fredo.ai.data.db.MemoryEntity
import com.fredo.ai.data.db.MemoryStatus
import com.fredo.ai.ui.components.EnumDropdown
import com.fredo.ai.ui.components.ScreenTitle
import com.fredo.ai.ui.vm.MemoryViewModel

@Composable
fun MemoryScreen(vm: MemoryViewModel = viewModel()) {
    val list by vm.items.collectAsStateWithLifecycle()
    val profile by vm.profile.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<MemoryEntity?>(null) }
    var creating by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<MemoryEntity?>(null) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importProfile(uri)
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.export(uri)
    }
    val isOwner = profile?.isOwner() == true
    val pending = list.count { it.status == MemoryStatus.PENDIENTE.name }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle(
            "Memoria",
            "${list.size} recuerdos · $pending pendientes de validar. Solo se envían al proveedor los pertinentes para cada mensaje."
        )
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { creating = true }) { Text("Añadir") }
                if (isOwner) OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) { Text("Importar perfil") }
                OutlinedButton(onClick = { exportLauncher.launch("fredo_memoria.json") }) { Text("Exportar") }
            }
            if (pending > 0) {
                TextButton(onClick = { vm.confirmAllPending() }) { Text("Confirmar todos los pendientes") }
            }
            message?.let { msg ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(msg, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { vm.clearMessage() }) { Text("OK") }
                    }
                }
            }
        }
        if (list.isEmpty()) {
            Text(
                "Todavía no hay recuerdos. Añade uno o, si eres el propietario, importa perfil_inicial.json desde tu teléfono.",
                modifier = Modifier.padding(16.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(list, key = { it.id }) { m ->
                MemoryCard(
                    m,
                    onConfirm = { vm.setStatus(m, MemoryStatus.CONFIRMADO) },
                    onEdit = { editing = m },
                    onRetire = {
                        vm.setStatus(m, if (m.status == MemoryStatus.RETIRADO.name) MemoryStatus.PENDIENTE else MemoryStatus.RETIRADO)
                    },
                    onDelete = { deleting = m }
                )
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }

    if (creating || editing != null) {
        MemoryDialog(
            existing = editing,
            onDismiss = { creating = false; editing = null },
            onSave = { text, cat, type, conf, sens, status, shared ->
                vm.save(editing, text, cat, type, conf, sens, status, shared)
                creating = false
                editing = null
            }
        )
    }
    deleting?.let { m ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("¿Eliminar este recuerdo?") },
            text = { Text("Se borra de forma definitiva. Si solo quieres que FREDO deje de usarlo, elige «Retirar».") },
            confirmButton = { TextButton(onClick = { vm.delete(m); deleting = null }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun MemoryCard(
    m: MemoryEntity,
    onConfirm: () -> Unit,
    onEdit: () -> Unit,
    onRetire: () -> Unit,
    onDelete: () -> Unit
) {
    val retired = m.status == MemoryStatus.RETIRADO.name
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(12.dp)) {
            Text(
                m.summary,
                style = MaterialTheme.typography.bodyMedium,
                color = if (retired) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(4.dp))
            Text(
                buildString {
                    append(m.category).append(" · ")
                    append(EvidenceType.from(m.evidenceType).label).append(" · ")
                    append("confianza ").append(Level.from(m.confidence).label.lowercase()).append(" · ")
                    append("sensibilidad ").append(Level.from(m.sensitivity).label.lowercase()).append(" · ")
                    append(MemoryStatus.from(m.status).label)
                    if (m.sharedWithFamily) append(" · visible para familia")
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row {
                if (m.status == MemoryStatus.PENDIENTE.name) TextButton(onClick = onConfirm) { Text("Confirmar") }
                TextButton(onClick = onEdit) { Text("Editar") }
                TextButton(onClick = onRetire) { Text(if (retired) "Restaurar" else "Retirar") }
                TextButton(onClick = onDelete) { Text("Eliminar") }
            }
        }
    }
}

@Composable
private fun MemoryDialog(
    existing: MemoryEntity?,
    onDismiss: () -> Unit,
    onSave: (String, String, EvidenceType, Level, Level, MemoryStatus, Boolean) -> Unit
) {
    var summary by remember { mutableStateOf(existing?.summary ?: "") }
    var category by remember { mutableStateOf(existing?.category ?: "general") }
    var type by remember { mutableStateOf(EvidenceType.from(existing?.evidenceType ?: EvidenceType.HECHO.name)) }
    var confidence by remember { mutableStateOf(Level.from(existing?.confidence)) }
    var sensitivity by remember { mutableStateOf(Level.from(existing?.sensitivity)) }
    var status by remember {
        mutableStateOf(MemoryStatus.from(existing?.status ?: MemoryStatus.CONFIRMADO.name))
    }
    var shared by remember { mutableStateOf(existing?.sharedWithFamily ?: false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Nuevo recuerdo" else "Editar recuerdo") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(summary, { summary = it }, label = { Text("Recuerdo (resumen)") }, minLines = 2)
                OutlinedTextField(category, { category = it }, label = { Text("Categoría") }, singleLine = true)
                EnumDropdown("Tipo", type, EvidenceType.entries.toList(), { it.label }, { type = it })
                EnumDropdown("Confianza", confidence, Level.entries.toList(), { it.label }, { confidence = it })
                EnumDropdown("Sensibilidad", sensitivity, Level.entries.toList(), { it.label }, { sensitivity = it })
                EnumDropdown("Estado", status, MemoryStatus.entries.toList(), { it.label }, { status = it })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = shared, onCheckedChange = { shared = it })
                    Text("Permitir que perfiles familiares lo usen (no aplica a sensibilidad alta)", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(summary, category, type, confidence, sensitivity, status, shared) }, enabled = summary.isNotBlank()) {
                Text("Guardar")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
