package com.fredo.ai.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.fredo.ai.ui.components.ProfileGate
import com.fredo.ai.ui.screens.ChatScreen
import com.fredo.ai.ui.screens.MemoryScreen
import com.fredo.ai.ui.screens.ProfilesScreen
import com.fredo.ai.ui.screens.SettingsScreen

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("chat", "Chat", Icons.Filled.Home),
    Tab("memory", "Memoria", Icons.Filled.Favorite),
    Tab("profiles", "Perfiles", Icons.Filled.Person),
    Tab("settings", "Ajustes", Icons.Filled.Settings)
)

@Composable
fun FredoNavHost() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route

    fun go(target: String) {
        nav.navigate(target) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                for (t in tabs) {
                    NavigationBarItem(
                        selected = route == t.route,
                        onClick = { go(t.route) },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(nav, startDestination = "chat", modifier = Modifier.padding(padding)) {
            composable("chat") { ProfileGate { ChatScreen(onOpenSettings = { go("settings") }) } }
            composable("memory") { ProfileGate { MemoryScreen() } }
            composable("profiles") { ProfilesScreen() }
            composable("settings") { SettingsScreen() }
        }
    }
}
