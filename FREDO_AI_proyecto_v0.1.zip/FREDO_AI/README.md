# FREDO AI — primera versión (0.1.0)

App Android en Kotlin + Jetpack Compose. Chat con proveedor de IA configurable, memoria persistente y revisable,
perfiles con PIN opcional, tema oscuro/claro con esfera luminosa y diagnóstico de conexión.

> **Estado honesto:** el código fue escrito y revisado de forma estática, pero **NO se ha compilado ni ejecutado
> en un dispositivo**. Ver `docs/ESTADO_DE_FUNCIONES.md`. El primer paso es compilar y corregir lo que el compilador señale.

## Cómo obtener el APK

### Opción A — GitHub Actions (se puede hacer desde el móvil, sin instalar nada)
1. Crea un repositorio **PRIVADO** en GitHub y sube el contenido de esta carpeta (la web de GitHub permite subir archivos desde el navegador).
2. Entra en la pestaña **Actions** → **Build APK (debug)** → **Run workflow**.
3. Al terminar (unos minutos), abre la ejecución y descarga el artefacto **FREDO_AI-debug-apk** (un ZIP con `app-debug.apk`).
4. Si el compilador marca errores, copia el mensaje del log y pásamelo para corregirlo.
5. Instala el APK en tu teléfono (hay que permitir «instalar apps de origen desconocido» para tu navegador o gestor de archivos).

### Opción B — Android Studio (ordenador)
Abre la carpeta, deja que sincronice Gradle (usa Gradle 8.9 y JDK 17) y ejecuta `Run` o `Build > Build APK(s)`.
No incluí `gradlew` ni `gradle-wrapper.jar` (no se pueden generar sin Gradle y red); Android Studio lo gestiona, o ejecuta `gradle wrapper` una vez.

## Primer uso
1. **Ajustes** → elige proveedor (OpenAI/compatible, Anthropic o Gemini), revisa dirección y **nombre del modelo** (los nombres cambian; si falla, verifícalo en la documentación del proveedor), pega tu **clave API** → *Guardar* → *Probar conexión*.
   La clave se guarda cifrada en el teléfono (Android Keystore). No está en el código ni en el APK.
2. **Memoria** → *Importar perfil* → selecciona tu `perfil_inicial.json` (está en el ZIP original). Todo entra como **«pendiente de validar»**; revísalo, edita, retira o confirma.
3. **Perfiles** → crea perfiles familiares. El PIN es un candado sencillo contra curiosos, **no cifra** los datos.

## Privacidad
- `perfil_inicial.json` y los chats **no están en este proyecto ni en el APK**. Se importa el perfil desde tu teléfono; los chats no se usan todavía.
- El `.gitignore` excluye esos archivos. Mantén el repositorio privado.
- Al chatear, se envían al proveedor elegido: tu mensaje, el historial reciente (20 mensajes) y solo los recuerdos pertinentes. Revisa la política de datos de tu proveedor.
- `allowBackup=false`: Android no respalda la base de datos ni las claves. Usa *Memoria → Exportar* para guardar copia de tus recuerdos.

## Documentos
- `docs/ESTADO_DE_FUNCIONES.md` — qué está implementado, probado y pendiente.
- `docs/ARQUITECTURA_TECNICA.md` — estructura del código.
- `docs/PLAN_DE_PRUEBAS.md` — lista de pruebas manuales a ejecutar en el teléfono.
